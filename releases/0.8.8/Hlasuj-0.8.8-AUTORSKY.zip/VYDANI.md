# Hlasuj! by MiloslavHub 0.8.8

Nasazený aplikační commit: 213e999ca314be9a85178a1eace88ba203a9e24a.
Commit předání zdrojů a dokumentace: 66af2f82bc0657076b24c121febecb0e1f7cdd31.
Schéma: 0.8.5, bez migrace pro přechod z 0.8.5.
Ověření: 269 kontrol, včetně skutečné WordPress/DB integrace a souběhu; navíc místní souběžné dávky 30 a 100 hlasů. Hostingová kapacita a dlouhodobý polling tím nejsou prokázány.
Nasazeno 5. 10. 2026 na hlasuj.miloslavhub.cz. Stav původního nasazení nedokládá stav nové zákaznické instalace.
Domácí úkoly, kompletní i18n, obsahový import/export a oddělené organizace zůstávají dalšími etapami.
Licenční a obchodní podmínky vlastního frontendu a assets musí autor dokončit; plugin deklaruje GPL-2.0-or-later, QRCode.js MIT.
