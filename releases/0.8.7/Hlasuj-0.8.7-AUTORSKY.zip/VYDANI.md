# Hlasuj! by MiloslavHub 0.8.7

Nasazený aplikační commit: 40dce6213af07b01f4f9f2bf428786709979c109.
Commit předání zdrojů a dokumentace: d6bc71dbe966453a9b257db55a73d1a4f57aac07.
Schéma: 0.8.5, bez migrace pro přechod z 0.8.5.
Ověření: syntaxe, 51 kontraktových, 18 HTTP, 11 prohlížečových a 19 skutečných WordPress/DB integračních kontrol.
Nasazeno 2. 10. 2026 na hlasuj.miloslavhub.cz. Stav původního nasazení nedokládá stav nové zákaznické instalace.
Domácí úkoly, kompletní i18n, obsahový import/export a oddělené organizace zůstávají dalšími etapami.
Licenční a obchodní podmínky vlastního frontendu a assets musí autor dokončit; plugin deklaruje GPL-2.0-or-later, QRCode.js MIT.
