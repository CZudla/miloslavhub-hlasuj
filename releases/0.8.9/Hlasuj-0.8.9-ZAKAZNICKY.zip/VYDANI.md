# Hlasuj! by MiloslavHub 0.8.9

Nasazený aplikační commit: 2168e3eef1f371d5588d1842813637694247f992.
Commit předání zdrojů a dokumentace: a68ea30476e80fa41b39baa4afab974c517d18af.
Schéma: 0.8.5, bez migrace pro přechod z 0.8.5.
Ověření: 330 kontrol, včetně skutečné WordPress/DB integrace, přenosu obsahu, učitelské administrace a souběhu; navíc místní souběžné dávky 30 a 100 hlasů. Hostingová kapacita a dlouhodobý polling tím nejsou prokázány.
Nasazeno 5. 10. 2026 na hlasuj.miloslavhub.cz. Stav původního nasazení nedokládá stav nové zákaznické instalace.
Přenos předmětu s náhledem a importem nových konceptů je dostupný ve formátu JSON v1. Rozsah a omezení popisuje příručka přenosu. Domácí úkoly, kompletní i18n a oddělené organizace zůstávají dalšími etapami.
Licenční a obchodní podmínky vlastního frontendu a assets musí autor dokončit; plugin deklaruje GPL-2.0-or-later, QRCode.js MIT.
