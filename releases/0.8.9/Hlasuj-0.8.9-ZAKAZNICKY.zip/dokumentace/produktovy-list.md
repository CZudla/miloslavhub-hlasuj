# Hlasuj! by MiloslavHub
## Zapojte publikum. Bez zdržování.
Webové ankety a kvízy pro společnou výuku. Studenti otevřou QR kód v prohlížeči. Učitel určí, kdy hlasování začne.
## Od otázky ke společné diskusi
1. Připravte otázku a ukažte QR.
2. Nechte studenty připojit a spusťte hlasování.
3. Proberte odpovědi na projekci.
## Co nabízí vydání 0.8.9
- Živé ankety a kvízy s učitelským spuštěním.
- Trvalé odkazy otázek a připojení bez studentského účtu.
- Projekci výsledků a volitelný soutěžní režim.
- Dlouhodobé ankety a CSV export živých výsledků.
- Přenos předmětu kolegovi pomocí JSON s náhledem importu.
## Vyzkoušejte ukázku
hlasuj.miloslavhub.cz/demo/
Navrženo učitelem pro učitele. Samostatný projekt MiloslavHub.
## Pro vlastní provoz
Frontend + WordPress plugin + samostatná hlasovací databáze. Instalační podmínky, soukromí a licence jsou popsány v dodané příručce. Domácí úkoly, plné cs/en rozhraní a oddělené organizace jsou plánované funkce.
